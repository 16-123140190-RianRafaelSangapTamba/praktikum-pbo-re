file = open("me.txt","w")

file.write("nama saya exaudi.\n")
file.write("saya ingin bergerak dari kemalasan.\n")
file.write("yang menyiksa.\n")

file.close()

print(f"file me.txt berhasil di buat")